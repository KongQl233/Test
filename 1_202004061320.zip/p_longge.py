# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np

def chazhi(X,Y,x):
    #计算x点的插值
    sum=Y[0]
    temp=np.zeros((len(X),len(X)))
    #将第一行赋值
    for i in range(0,len(X)):
        temp[i,0]=Y[i]
    temp_sum=1.0
    for i in range(1,len(X)):
        #x的多项式
        temp_sum=temp_sum*(x-X[i-1])
        #计算均差
        for j in range(i,len(X)):
            temp[j,i]=(temp[j,i-1]-temp[j-1,i-1])/(X[j]-X[j-i])
        sum+=temp_sum*temp[i,i] 
    return sum

#设置画布的标题及大小
plt.figure(figsize=(16,9))
plt.title("拟合曲线")
color = ['red','blue','black']

#设置不同取值点数目作为绘图的数据
for j,i in enumerate([5,9,11]):
    X = np.linspace(-5, 5, num= i)
    Y= np.array(1 / (1 + X * X))
    xs=np.linspace(np.min(X),np.max(X),1000,endpoint=True)
    
    ys=[]
    for x in xs:
        ys.append(chazhi(X,Y,x))

#绘制图像
    plt.plot(X,Y,'s',label=f"n={i}", color=color[j])#蓝点表示原来的值
    plt.plot(xs,ys,label='', color=color[j])#插值曲线 用红蓝黑对应不同取值点数目的不同结果

xs=np.linspace(-5,5,100,endpoint=True)
plt.plot(xs,np.array(1 / (1 + xs * xs)),'b',label='y=1 / (1 + x**2)')#原曲线
plt.xlabel('x')  
plt.ylabel('y')  
plt.legend(loc=4)#标识写在右下角

