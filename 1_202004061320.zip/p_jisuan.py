import matplotlib.pyplot as plt
import numpy as np
import math

#构造拟合用函数
def linefit(x , y):
  N = float(len(x))
  sumx,sumy,sumxx,sumyy,sumxy=0,0,0,0,0
  for i in range(0,int(N)):
    sumx += x[i]
    sumy += y[i]
    sumxx += x[i]*x[i]
    sumyy += y[i]*y[i]
    sumxy += x[i]*y[i]
  a = (sumy*sumx/N -sumxy)/( sumx*sumx/N -sumxx)
  b = (sumy - a*sumx)/N
  r = abs(sumy*sumx/N-sumxy)/math.sqrt((sumxx-sumx*sumx/N)*(sumyy-sumy*sumy/N))
  return a,b,r

#数据样本 
x=np.array([1.9,2.0,2.1,2.5,2.7,2.7,3.5,3.5,4.0,4.0,4.5,4.6,5.0,5.2,6.0,6.3,6.5,7.1,8.0,8.0,8.9,9.0,9.5,10.0])
y=np.array([1.4,1.3,1.8,2.5,2.8,2.5,3.0,2.7,4.0,3.5,4.2,3.5,5.5,5.0,5.5,6.4,6.0,5.3,6.5,7.0,8.5,8.0,8.1,8.1])

a,b,r=linefit(x,y)#计算出a，b，r的值
y1=a*x+b#拟合的直线

#绘制图表
plt.figure(figsize=(8, 6))
plt.scatter(x, y, color='red', label='Sample data', linewidth=2)
plt.plot(x, y1, color='blue', label='Fitting Curve', linewidth=2)
plt.legend()  
plt.xlabel('x', fontproperties='simHei', fontsize=12)
plt.ylabel('y', fontproperties='simHei', fontsize=12)
plt.show()

print(a,b)
